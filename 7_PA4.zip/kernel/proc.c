#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "schedinfo.h"

struct cpu cpus[NCPU];

struct proc proc[NPROC];

struct proc *initproc;
// Q5: Global scheduling policy.
// 0 = Round Robin, 1 = Priority.
static int sched_policy = 0;

// Last process-table slot selected at each priority level.
// Initialize to NPROC-1 so the first scan starts at slot 0.
static uint prio_cursor[3] = {
  NPROC - 1,
  NPROC - 1,
  NPROC - 1
};

// Q3: fork timing instrumentation.
int forkwatch_enabled = 0;
struct spinlock forkwatch_lock;
extern struct spinlock tickslock;
extern uint ticks;
extern volatile uint booted_harts;

int nextpid = 1;
struct spinlock pid_lock;

extern void forkret(void);
static void freeproc(struct proc *p);

extern char trampoline[]; // trampoline.S

// helps ensure that wakeups of wait()ing
// parents are not lost. helps obey the
// memory model when using p->parent.
// must be acquired before any p->lock.
struct spinlock wait_lock;

// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
  }
}

// initialize the proc table.
void
procinit(void)
{
  struct proc *p;

  initlock(&pid_lock, "nextpid");
  initlock(&wait_lock, "wait_lock");
  initlock(&forkwatch_lock, "forkwatch");
  for (p = proc; p < &proc[NPROC]; p++) {
    initlock(&p->lock, "proc");
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
  }
}

// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
  int id = r_tp();
  return id;
}

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
  int id = cpuid();
  struct cpu *c = &cpus[id];
  return c;
}

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
  push_off();
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
  pop_off();
  return p;
}

int
allocpid()
{
  int pid;

  acquire(&pid_lock);
  pid = nextpid;
  nextpid = nextpid + 1;
  release(&pid_lock);

  return pid;
}

// Look in the process table for an UNUSED proc.
// If found, initialize state required to run in the kernel,
// and return with p->lock held.
// If there are no free procs, or a memory allocation fails, return 0.
static struct proc *
allocproc(void)
{
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->state == UNUSED) {
      goto found;
    } else {
      release(&p->lock);
    }
  }
  return 0;

found:
  p->pid = allocpid();
  p->state = USED;

  // Initialize scheduling statistics
  p->nsched = 0;
  p->rticks = 0;
  p->lastcpu = -1;
  p->slice = 1;
  p->used = 0;
  // Allow every possible hart; scheduler only runs on booted harts.
  p->affinity = (1U << NCPU) - 1;
  p->prio = 1;
  p->ctime = -1;  // -1 means this process was not fork-watched.
  p->ftime = 0;
  p->firstcpu = -1;
  p->first_run = 0;

  // Allocate a trapframe page.
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // An empty user page table.
  p->pagetable = proc_pagetable(p);
  if (p->pagetable == 0) {
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // Set up new context to start executing at forkret,
  // which returns to user space.
  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  return p;
}

// free a proc structure and the data hanging from it,
// including user pages.
// p->lock must be held.
static void
freeproc(struct proc *p)
{
  if (p->trapframe)
    kfree((void *)p->trapframe);
  p->trapframe = 0;
  if (p->pagetable)
    proc_freepagetable(p->pagetable, p->sz);
  p->pagetable = 0;
  p->sz = 0;
  p->pid = 0;
  p->nsched = 0;
  p->rticks = 0;
  p->lastcpu = -1;
  p->slice = 1;
  p->used = 0;
  p->ctime = -1;
  p->ftime = 0;
  p->firstcpu = -1;
  p->first_run = 0;
  p->name[0] = 0;
  p->chan = 0;
  p->killed = 0;
  p->xstate = 0;
  p->state = UNUSED;
  p->affinity = 0;
  p->prio = 1;
}

// Create a user page table for a given process, with no user memory,
// but with trampoline and trapframe pages.
pagetable_t
proc_pagetable(struct proc *p)
{
  pagetable_t pagetable;

  // An empty page table.
  pagetable = uvmcreate();
  if (pagetable == 0)
    return 0;

  // map the trampoline code (for system call return)
  // at the highest user virtual address.
  // only the supervisor uses it, on the way
  // to/from user space, so not PTE_U.
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
               PTE_R | PTE_X) < 0) {
    uvmfree(pagetable, 0);
    return 0;
  }

  // map the trapframe page just below the trampoline page, for
  // trampoline.S.
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
               PTE_R | PTE_W) < 0) {
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    uvmfree(pagetable, 0);
    return 0;
  }

  return pagetable;
}

// Free a process's page table, and free the
// physical memory it refers to.
void
proc_freepagetable(pagetable_t pagetable, uint64 sz)
{
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
  uvmfree(pagetable, sz);
}

// Set up first user process.
void
userinit(void)
{
  struct proc *p;

  p = allocproc();
  initproc = p;

  p->cwd = namei("/");

  p->state = RUNNABLE;

  release(&p->lock);
}

// Grow or shrink user memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint64 sz;
  struct proc *p = myproc();

  sz = p->sz;
  if (n > 0) {
    if (sz + n > TRAPFRAME) {
      return -1;
    }
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
      return -1;
    }
  } else if (n < 0) {
    sz = uvmdealloc(p->pagetable, sz, sz + n);
  }
  p->sz = sz;
  return 0;
}

// Create a new process, copying the parent.
// Sets up child kernel stack to return as if from fork() system call.
int
kfork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *p = myproc();
  int parent_slice;
  int parent_prio;
  uint parent_affinity;

  acquire(&p->lock);
  parent_slice = p->slice;
  parent_affinity = p->affinity;
  parent_prio = p->prio;
  release(&p->lock);

  // Allocate process.
  if ((np = allocproc()) == 0) {
    return -1;
  }

  // Copy user memory from parent to child.
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    freeproc(np);
    release(&np->lock);
    return -1;
  }
  np->sz = p->sz;
  np->slice = parent_slice;
  np->used = 0;
  np->affinity = parent_affinity;
  np->prio = parent_prio;

  // copy saved user registers.
  *(np->trapframe) = *(p->trapframe);

  // Cause fork to return 0 in the child.
  np->trapframe->a0 = 0;

  // increment reference counts on open file descriptors.
  for (i = 0; i < NOFILE; i++)
    if (p->ofile[i])
      np->ofile[i] = filedup(p->ofile[i]);
  np->cwd = idup(p->cwd);

  safestrcpy(np->name, p->name, sizeof(p->name));

  pid = np->pid;

  release(&np->lock);

  acquire(&wait_lock);
  np->parent = p;
  release(&wait_lock);

  // Check whether fork watching is enabled.  Do not hold this lock
  // while acquiring tickslock or a process lock.
  int watch;
  acquire(&forkwatch_lock);
  watch = forkwatch_enabled;
  release(&forkwatch_lock);

  // Use the same lock order as clockintr(): tickslock, then p->lock.
  acquire(&tickslock);
  acquire(&np->lock);
  np->ctime = watch ? ticks : -1;
  np->ftime = 0;
  np->firstcpu = -1;
  np->first_run = 0;
  np->state = RUNNABLE;
  release(&np->lock);
  release(&tickslock);

  return pid;
}

// Pass p's abandoned children to init.
// Caller must hold wait_lock.
void
reparent(struct proc *p)
{
  struct proc *pp;

  for (pp = proc; pp < &proc[NPROC]; pp++) {
    if (pp->parent == p) {
      pp->parent = initproc;
      wakeup(initproc);
    }
  }
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait().
void
kexit(int status)
{
  struct proc *p = myproc();

  if (p == initproc)
    panic("init exiting");

  // Close all open files.
  for (int fd = 0; fd < NOFILE; fd++) {
    if (p->ofile[fd]) {
      struct file *f = p->ofile[fd];
      fileclose(f);
      p->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(p->cwd);
  end_op();
  p->cwd = 0;

  acquire(&wait_lock);

  // Give any children to init.
  reparent(p);

  // Parent might be sleeping in wait().
  wakeup(p->parent);

  acquire(&p->lock);

  p->xstate = status;
  p->state = ZOMBIE;

  release(&wait_lock);

  // Jump into the scheduler, never to return.
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
kwait(uint64 addr)
{
  struct proc *pp;
  int havekids, pid;
  struct proc *p = myproc();

  acquire(&wait_lock);

  for (;;) {
    // Scan through table looking for exited children.
    havekids = 0;
    for (pp = proc; pp < &proc[NPROC]; pp++) {
      if (pp->parent == p) {
        // make sure the child isn't still in exit() or swtch().
        acquire(&pp->lock);

        havekids = 1;
        if (pp->state == ZOMBIE) {
          // Found one.
          pid = pp->pid;
          if (addr != 0 &&
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
                      sizeof(pp->xstate)) < 0) {
            release(&pp->lock);
            release(&wait_lock);
            return -1;
          }
          pp->parent = 0;
          freeproc(pp);
          release(&pp->lock);
          release(&wait_lock);
          return pid;
        }
        release(&pp->lock);
      }
    }

    // No point waiting if we don't have any children.
    if (!havekids || killed(p)) {
      release(&wait_lock);
      return -1;
    }

    // Wait for a child to exit.
    sleep_prepare(p); //DOC: wait-sleep
    release(&wait_lock);
    sleep();
    acquire(&wait_lock);
  }
}
// Select the highest-priority runnable process allowed on this hart.
// Returns the selected process with its p->lock held.
static struct proc *
pick_prio_proc(int hart)
{
  struct proc *p;
  uint hartbit = 1U << hart;

  for (;;) {
    int best = 3;

    // First pass: find the highest runnable priority.
    for (p = proc; p < &proc[NPROC]; p++) {
      acquire(&p->lock);

      if (p->state == RUNNABLE &&
          (p->affinity & hartbit) != 0 &&
          p->prio < best) {
        best = p->prio;
      }

      release(&p->lock);
    }

    if (best == 3)
      return 0;

    // Second pass: select the next process at that priority,
    // starting immediately after its round-robin cursor.
    uint cursor = __atomic_load_n(
        &prio_cursor[best], __ATOMIC_ACQUIRE);

    for (int offset = 1; offset <= NPROC; offset++) {
      int idx = (cursor + offset) % NPROC;
      p = &proc[idx];

      acquire(&p->lock);

      if (p->state == RUNNABLE &&
          p->prio == best &&
          (p->affinity & hartbit) != 0) {

        __atomic_store_n(
            &prio_cursor[best], idx, __ATOMIC_RELEASE);

        // Return with p->lock held.
        return p;
      }

      release(&p->lock);
    }

    // Candidate changed before selection. Retry.
  }
}
// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run.
//  - swtch to start running that process.
//  - eventually that process transfers control
//    via swtch back to the scheduler.

void
scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();

  c->proc = 0;

  for (;;) {
    intr_on();
    intr_off();

    int found = 0;
    int hart = cpuid();
    uint hartbit = 1U << hart;
    uint active_harts =
        __atomic_load_n(&booted_harts, __ATOMIC_ACQUIRE);

    int policy =
        __atomic_load_n(&sched_policy, __ATOMIC_ACQUIRE);

    p = 0;

    if (policy == 1) {
      // Priority scheduling.
      // Returns the selected process with its lock held.
      p = pick_prio_proc(hart);
    } else {
      // Original Round Robin scheduling.
      for (struct proc *q = proc; q < &proc[NPROC]; q++) {
        acquire(&q->lock);

        if (q->state == RUNNABLE &&
            (active_harts & hartbit) != 0 &&
            (q->affinity & hartbit) != 0) {
          p = q;
          break;
        }

        release(&q->lock);
      }
    }

    if (p != 0) {
      p->nsched++;
      p->lastcpu = hart;
      p->used = 0;

      p->state = RUNNING;
      c->proc = p;

      swtch(&c->context, &p->context);

      // Process has switched back to the scheduler.
      mycpu()->intena = 0;
      c->proc = 0;

      release(&p->lock);
      found = 1;
    }

    if (found == 0) {
      asm volatile("wfi");
    }
  }
}
// Switch to scheduler.  Must hold only p->lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->noff, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if (!holding(&p->lock))
    panic("sched p->lock");
  if (mycpu()->noff != 1)
    panic("sched locks");
  if (p->state == RUNNING)
    panic("sched RUNNING");
  if (intr_get())
    panic("sched interruptible");

  intena = mycpu()->intena;
  swtch(&p->context, &mycpu()->context);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
  struct proc *p = myproc();
  acquire(&p->lock);
  p->state = RUNNABLE;
  sched();
  release(&p->lock);
}

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
  int hart = cpuid();
  int print_watch = 0;
  int pid = 0;
  int elapsed = 0;
  uint now;

  // scheduler() enters forkret() with p->lock held.  Release it before
  // taking tickslock: clockintr() takes tickslock before process locks.
  release(&p->lock);

  acquire(&tickslock);
  now = ticks;
  release(&tickslock);

  acquire(&p->lock);
  if (p->ctime >= 0 && !p->first_run) {
    p->first_run = 1;
    p->ftime = now;
    p->firstcpu = hart;
    pid = p->pid;
    elapsed = p->ftime - p->ctime;
    print_watch = 1;
  }
  release(&p->lock);

  // Never print while holding a process or ticks lock.
  if (print_watch) {
    printk("pid %d: first run on hart %d, %d ticks after fork\n",
           pid, hart, elapsed);
  }

  if (first) {
    first = 0;

    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);

    // We can invoke kexec() now that the file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    if (p->trapframe->a0 == -1) {
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
  uint64 satp = MAKE_SATP(p->pagetable);
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
  ((void (*)(uint64))trampoline_userret)(satp);
}

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
  struct proc *p = myproc();

  acquire(&p->lock);
  if (chan == 0)
    panic("sleep_prepare: zero chan");
  p->chan = chan;
  release(&p->lock);
}

// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
  struct proc *p = myproc();

  acquire(&p->lock);
  if (p->chan != 0) {
    p->state = SLEEPING;
    sched();
  }
  release(&p->lock);
}

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->chan == chan) {
      // If the process is waiting for wakeups on this channel,
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
        p->state = RUNNABLE;
      }
    }
    release(&p->lock);
  }
}

// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
  struct proc *p;

  if (pid == 0)
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if (p->pid == pid) {
      p->killed = 1;
      if (p->state == SLEEPING) {
        // Wake process from sleep().
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

void
setkilled(struct proc *p)
{
  acquire(&p->lock);
  p->killed = 1;
  release(&p->lock);
}

int
killed(struct proc *p)
{
  int k;

  acquire(&p->lock);
  k = p->killed;
  release(&p->lock);
  return k;
}

// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
  struct proc *p = myproc();
  if (user_dst) {
    return copyout(p->pagetable, p->sz, dst, src, len);
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}

// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
  struct proc *p = myproc();
  if (user_src) {
    return copyin(p->pagetable, p->sz, dst, src, len);
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}

// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
    // clang-format off
    [UNUSED]    = "unused",
    [USED]      = "used",
    [SLEEPING]  = "sleep ",
    [RUNNABLE]  = "runble",
    [RUNNING]   = "run   ",
    [ZOMBIE]    = "zombie"
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
  for (p = proc; p < &proc[NPROC]; p++) {
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    printk("%d %s %s", p->pid, state, p->name);
    printk("\n");
  }
  
}
int
proc_schedinfo(int pid, struct schedinfo *si)
{
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);

    if (p->state != UNUSED && p->pid == pid) {
      memset(si, 0, sizeof(*si));

      si->pid = p->pid;
      si->state = p->state;
      si->nsched = p->nsched;
      si->rticks = p->rticks;
      si->lastcpu = p->lastcpu;
      si->slice = p->slice;
      si->ctime = p->ctime;
      si->ftime = p->ftime;
      si->firstcpu = p->firstcpu;
      si->prio = p->prio;
      safestrcpy(si->name, p->name, sizeof(si->name));
      si->affinity = p->affinity &
                     __atomic_load_n(&booted_harts, __ATOMIC_ACQUIRE);

      release(&p->lock);
      return 0;
    }

    release(&p->lock);
  }

  return -1;
}
int
proc_setslice(int pid, int n)
{
  struct proc *p;

  if (n < 1 || n > 100)
    return -1;

  if (pid == 0)
    pid = myproc()->pid;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);

    if (p->state != UNUSED && p->pid == pid) {
      p->slice = n;
      p->used = 0;
      release(&p->lock);
      return 0;
    }

    release(&p->lock);
  }

  return -1;
}

int
proc_forkwatch(int on)
{
  int old;

  acquire(&forkwatch_lock);
  old = forkwatch_enabled;
  forkwatch_enabled = on ? 1 : 0;
  release(&forkwatch_lock);

  return old;
}


// Set the CPU affinity mask for a process.
// pid == 0 refers to the calling process.
// A valid mask must be nonzero and contain only booted harts.
int
proc_setaffinity(int pid, int mask)
{
  struct proc *p;
  struct proc *caller = myproc();
  int hart = cpuid();
  uint allowed = __atomic_load_n(&booted_harts, __ATOMIC_ACQUIRE);
  uint newmask = (uint)mask;

  if (mask <= 0 || (newmask & allowed) == 0)
    return -1;

  if (pid == 0)
    pid = caller->pid;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);

    if (p->state != UNUSED && p->pid == pid) {
      p->affinity = newmask;
      int must_yield = (p == caller && (newmask & (1U << hart)) == 0);
      release(&p->lock);

      // Do not continue running on a hart excluded from our own mask.
      if (must_yield)
        yield();
      return 0;
    }

    release(&p->lock);
  }

  return -1;
}

// Return a process's affinity mask, or -1 if pid does not exist.
// pid == 0 refers to the calling process.
int
proc_getaffinity(int pid)
{
  struct proc *p;
  uint active = __atomic_load_n(&booted_harts, __ATOMIC_ACQUIRE);

  if (pid == 0)
    pid = myproc()->pid;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);

    if (p->state != UNUSED && p->pid == pid) {
      int mask = (int)(p->affinity & active);
      release(&p->lock);
      return mask;
    }

    release(&p->lock);
  }

  return -1;
}
// Change or query the global scheduling policy.
// 0 = Round Robin, 1 = Priority, -1 = query.
int
proc_schedpolicy(int policy)
{
  int old;

  if (policy < -1 || policy > 1)
    return -1;

  if (policy == -1)
    return __atomic_load_n(&sched_policy, __ATOMIC_ACQUIRE);

  old = __atomic_exchange_n(&sched_policy, policy, __ATOMIC_ACQ_REL);
  return old;
}

// Check whether a higher-priority process can run on this hart.
static int
higher_prio_runnable(int prio, int hart)
{
  struct proc *p;
  uint hartbit = 1U << hart;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);

    if (p->state == RUNNABLE &&
        p->prio < prio &&
        (p->affinity & hartbit) != 0) {
      release(&p->lock);
      return 1;
    }

    release(&p->lock);
  }

  return 0;
}

// Set a process's priority.
// pid == 0 refers to the calling process.
int
proc_setprio(int pid, int prio)
{
  struct proc *p;
  struct proc *caller = myproc();
  int oldprio = -1;

  if (prio < 0 || prio > 2)
    return -1;

  if (pid == 0)
    pid = caller->pid;

  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);

    if (p->state != UNUSED && p->pid == pid) {
      oldprio = p->prio;
      p->prio = prio;
      release(&p->lock);
      break;
    }

    release(&p->lock);
  }

  if (oldprio == -1)
    return -1;

  // If the caller lowered its own priority under PRIO,
  // immediately yield when a higher-priority process is runnable.
  if (p == caller &&
      prio > oldprio &&
      __atomic_load_n(&sched_policy, __ATOMIC_ACQUIRE) == 1 &&
      higher_prio_runnable(prio, cpuid())) {
    yield();
  }

  return 0;
}
// Check whether the current process must give up its CPU.
int
proc_preempt_needed(void)
{
  struct proc *current = myproc();
  struct proc *p;
  int current_prio;
  int hart = cpuid();
  uint hartbit = 1U << hart;
  uint active = __atomic_load_n(&booted_harts, __ATOMIC_ACQUIRE);

  if (current == 0)
    return 0;

  // Read current process properties under its lock.
  acquire(&current->lock);
  current_prio = current->prio;

  // Q4: A process must leave a hart excluded by its affinity.
  if ((current->affinity & hartbit) == 0) {
    release(&current->lock);
    return 1;
  }

  release(&current->lock);

  // Q5: Priority preemption applies only under PRIO policy.
  if (__atomic_load_n(&sched_policy, __ATOMIC_ACQUIRE) != 1)
    return 0;

  // Check whether a higher-priority runnable process can use this hart.
  for (p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);

    if (p->state == RUNNABLE &&
        p->prio < current_prio &&
        (p->affinity & hartbit) != 0 &&
        (active & hartbit) != 0) {
      release(&p->lock);
      return 1;
    }

    release(&p->lock);
  }

  return 0;
}
// Q6 Bonus: return PIDs of all non-UNUSED processes.
int
proc_getpids(uint64 addr, int max)
{
  struct proc *p;
  struct proc *cur = myproc();
  int pids[NPROC];
  int count = 0;

  if (max <= 0)
    return 0;

  if (max > NPROC)
    max = NPROC;

  for (p = proc; p < &proc[NPROC] && count < max; p++) {
    acquire(&p->lock);

    if (p->state != UNUSED)
      pids[count++] = p->pid;

    release(&p->lock);
  }

  if (copyout(cur->pagetable, cur->sz, addr, (char *)pids,\
              count * sizeof(int)) < 0)
    return -1;

  return count;
}
